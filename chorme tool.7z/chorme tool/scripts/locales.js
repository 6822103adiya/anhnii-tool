/* Copyright (c) 2017 Kenzo. All rights reserved. */

export const bolorLocales = [
  {
    direction: "1",
    title: "Монгол <> Англи",
  },
  {
    direction: "3",
    title: "Монгол <> Герман",
  },
  {
    direction: "4",
    title: "Монгол <> Солонгос",
  },
  {
    direction: "5",
    title: "Монгол <> Япон",
  },
  {
    direction: "7",
    title: "Монгол <> Хятад",
  },
  {
    direction: "8",
    title: "Монгол <> Орос",
  },
];
